
# Informacio de la classe Empresa

Classe <b>Empresa</b> nom�s consta de un cunstructor y els respectius getters i setters dels<br>
atributs

![Diagrama de classes](/articles/diagrama.jpg)



